package com.geekbrains.lesson1;

import org.springframework.stereotype.Component;

@Component
public class MyBean2 implements MyBeans{
    public void printStatus() {
        System.out.println("Status: MyBean2 is working!");
    }
}
