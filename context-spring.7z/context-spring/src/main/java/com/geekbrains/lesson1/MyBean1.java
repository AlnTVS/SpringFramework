package com.geekbrains.lesson1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MyBean1 implements MyBeans{
    private MyBeans myBean;

    @Autowired
    public void setMyBean2(MyBeans myBean) {
        this.myBean = myBean;
    }

    public void printStatus() {
        System.out.println("Status: MyBean1 is working!");
    }

    public MyBeans getMyBean() {
        return myBean;
    }
}
