package com.geekbrains.lesson1;

public interface MyBeans {
    public void printStatus();
}
