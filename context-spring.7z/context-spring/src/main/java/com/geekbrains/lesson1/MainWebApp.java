package com.geekbrains.lesson1;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainWebApp {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(WebAppConfig.class);

        MyBean1 myBean1 = context.getBean("myBean1", MyBean1.class);
        MyBeans myBean2 = context.getBean("myBean2", MyBeans.class);
        myBean1.printStatus();
        myBean2.printStatus();

        myBean1.getMyBean().printStatus();
    }
}
